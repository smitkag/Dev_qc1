import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TagsrequestsService {

  constructor(private httpClient: HttpClient) { }
  // sendTags(tags) {
  //   return this.httpClient.post('url', tags);
  // }

  getTags() {
    return this.httpClient.get('assets/stockSymbolsAll.json');
  }

  sendRequestToGetTag(symbol) {
    return this.httpClient.get('https://api.iextrading.com/1.0/stock/'+symbol+'/book');
  }
}

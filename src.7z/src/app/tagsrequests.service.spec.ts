import { TestBed } from '@angular/core/testing';

import { TagsrequestsService } from './tagsrequests.service';

describe('TagsrequestsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TagsrequestsService = TestBed.get(TagsrequestsService);
    expect(service).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { TagsrequestsService } from './tagsrequests.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  items = [];
  item = [];
  re = [];
  tags = [];
  tagsChoosed = [];
  books = [];
  today: number = Date.now();
  private _widget = [];
  public get widget() {
    return this._widget;
  }
  public set widget(value) {
    this._widget = value;
  }
  private _TradingView = [];
  public get TradingView() {
    return this._TradingView;
  }
  public set TradingView(value) {
    this._TradingView = value;
  }
  mTag = [];
  ref;
  

  constructor(private requestTags: TagsrequestsService) { }
  ngOnInit() {
    console.log(this.item);
    this.requestTags.getTags().subscribe(
      (response: any[]) => {
        this.re = response;
        console.log(this.re);
        console.log(this.re.length);
        let x;
        for (x = 0; x <= this.re.length; x++) {
          this.items.push({display: this.re[x].symbol+' '+this.re[x].name, value: this.re[x].symbol})
        }
        console.log(this.items)
      },
      (error) => console.log(error)
    );
    console.log(this.ref);
  }
  // add or remove tag
  onItemRemovedOrAdded() {
    this.books = [];
    this.mTag = [];
    this.tagsChoosed = this.item.map(function (elem) {
      return elem.value;
    });
    console.log(this.tagsChoosed);
    console.log(this.tagsChoosed.length);
    if(this.tagsChoosed.length) {
      this.ref = "ok";
    }
    else {
      this.ref = "no";
    }

    for( let i = 0; i < this.tagsChoosed.length; i++) {
      for(let c = 0; c < this.re.length; c++) {
        if(this.re[c].symbol === this.tagsChoosed[i]) {
          this.mTag.push({"symb": this.re[c].symbol, "ech": this.re[c].exch});
          console.log(this.mTag);
        }
      }
    }
   for (let yy = 0; yy < this.mTag.length; yy++) {
      this.requestTags.sendRequestToGetTag(this.mTag[yy].symb).subscribe(
        (response) => {
          this.books.push(response);
          console.log(this.books);
          console.log(this.mTag[yy].symb);
          for (let xx = 0; xx <= this.re.length; xx++) {
            if (this.re[xx].symbol === this.mTag[yy].symb) {
              console.log(this.re[xx].symbol)
              const newLocal = this;
             // remove to REMOVE ABOVE to BUILD  
             // remove to REMOVE ABOVE to BUILD
              new TradingView.widget(
                {
                  "width": 525,
                  "height": 375,
                  // "autosize": true,
                  // NASDAQ below needs to be dynamic  NASDAQ | AMEX or NYSE - added to JSON
                  "symbol": this.re[xx].exch+":"+this.mTag[yy].symb,
                  "interval": "D",
                  "timezone": "Etc/UTC",
                  "theme": "Light",
                  "style": "1",
                  "locale": "en",
                  "toolbar_bg": "#f1f3f6",
                  "enable_publishing": false,
                  "allow_symbol_change": true,
                  "container_id": this.mTag[yy].symb
                }
              );
              // ***********REMOVE ABOVE to BUILD
              // ***********REMOVE ABOVE to BUILD
            }
          }
        },
        (error) => console.log(error)
      )
    }
  }
  printFunction() {
    window.print();
  }
}
